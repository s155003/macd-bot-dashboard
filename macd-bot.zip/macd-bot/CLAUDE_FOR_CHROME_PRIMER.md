# Primer for Claude for Chrome

Copy everything between the lines below and paste it as your first
message in a new Claude for Chrome side-panel chat. It gives the
browser-side Claude all the context it needs to help you create the
GitHub repo and walk you through pushing the project.

═══════════════════════════════════════════════════════════════════════

Hi Claude — I need your help putting a Python project up on GitHub
and walking me through the deployment.

## Context

I have a Python project called **macd-bot** sitting on my computer
in a folder I just unzipped. It's a MACD-based trading bot for
Alpaca paper trading, with a FastAPI + Plotly web dashboard layered
on top. The folder structure is:

    macd-bot/
    ├── main.py                  (original bot)
    ├── run_dashboard.py         (launches the web dashboard)
    ├── README.md
    ├── requirements.txt
    ├── pyproject.toml
    ├── uv.lock
    ├── Dockerfile
    ├── docker-compose.yml
    ├── .env.example
    ├── .gitignore
    ├── setup.sh                 (one-shot installer for macOS/Linux)
    ├── setup.ps1                (one-shot installer for Windows)
    ├── bot/
    │   ├── __init__.py
    │   ├── config.py
    │   ├── strategy.py
    │   ├── store.py
    │   └── runner.py
    ├── dashboard/
    │   ├── __init__.py
    │   ├── server.py
    │   ├── alpaca_client.py
    │   ├── chart_data.py
    │   └── static/
    │       └── index.html
    └── tests/
        ├── test_strategy.py
        ├── test_store.py
        └── test_server.py

Everything works — 23/23 tests pass. The dashboard shows live price
charts with MACD crossover markers, account state from Alpaca,
positions, P&L, and a real-time event log.

## What I want you to help me do

**Step 1 — Create a new GitHub repo through the github.com UI:**
- Navigate to github.com and sign in (I'll handle login if needed)
- Create a new repository named `macd-bot`
- Make it private to start (I can flip it public later)
- DO NOT initialize it with a README, .gitignore, or license — I
  already have those files locally and want to push them as-is
- Show me the repo URL when done

**Step 2 — Give me the exact terminal commands to run locally:**
After you create the repo, give me a single copy-pasteable block
of git commands to run in my terminal that will:
  1. Initialize git in the project folder
  2. Add all files (the .gitignore already excludes secrets and
     generated files)
  3. Make an initial commit with a good message
  4. Add the GitHub remote
  5. Push to main

**Step 3 — Sanity check before I push:**
Before I run the git push, remind me to verify:
  - My .env file is NOT being tracked (it's in .gitignore but
    double-check)
  - My data/ folder and *.db files are NOT being tracked
  - The repo is private if I want to keep my Alpaca keys workflow
    confidential

## What I do NOT want you to do

- Don't try to access my local terminal or files — you can't, and
  I'll handle the local commands myself
- Don't enter any API keys or secrets anywhere — those stay in my
  local .env file only
- Don't make the repo public without me explicitly confirming

Ready when you are. Start by opening github.com.

═══════════════════════════════════════════════════════════════════════
